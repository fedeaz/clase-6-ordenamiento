#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

void ordenar (int[], int );


void mostrarVector(int[],int);

#endif // FUNCIONES_H_INCLUDED
