#include <stdio.h>
#include <stdlib.h>
void ordenar(int[],int,int);

void mostrarVector(int[], int);

int main()
{
    int x[]={34,14,23,12,7};

    ordenar(x,5,0);

    mostrarVector(x,5);

    return 0;
}
void ordenar(int vec[], int tam, int m)
{
    int aux=0;
    for(int i = 0; i<tam-1; i++)
    {
        for(int j= i+1;j<tam;j++)
        {
            if (m == 0){
            if (vec[i]>vec[j])
            {
                aux = vec[i];
                vec[i]=vec[j];
                vec[j] = aux;
            }
            }
            else if (m == 1)
            {
              if (vec[i]<vec[j])
            {
                aux = vec[i];
                vec[i]=vec[j];
                vec[j] = aux;
            }
            }
    }
    }

}

void mostrarVector(int vec[], int tam){

  for(int i = 0 ; i < tam ;i ++)
      {
       printf("%d \n", vec[i]);
      }
       printf("\n");


}




